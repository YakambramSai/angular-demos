# Angular 7 Crash Course Project

This is the project based on the following crash course:
[Angular 7 Tutorial - Learn Angular 7 by Example](https://coursetro.com/posts/code/171/Angular-7-Tutorial---Learn-Angular-7-by-Example)

## More Awesome Content

Do me a big ol' favor and check out these awesome links. I release new video tutorials on full stack development Monday-Thursday @ 10:30 AM ET!

* Subscribe to the [DesignCourse YouTube Channel](http://youtube.com/designcourse)
* Check out the associated website [Coursetro Full Stack Development Training](https://coursetro.com)
* Chat with me and others on Discord: [DesignCourse Discord Server](https://discord.gg/a27CKAF)
* [Twitter](https://twitter.com/designcoursecom)
* [Facebook](https://facebook.com/coursetro)

Enjoy!